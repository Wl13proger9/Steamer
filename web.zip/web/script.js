
eel.get_version()(function(text) {document.getElementById("p2").innerText = "made by: Wl13Proger9 --- Version: "+text;});


document.addEventListener("keydown", function (event) {if (event.key === "F5" || (event.ctrlKey && event.key === "r")) {event.preventDefault();}});


document.addEventListener("contextmenu", function (event) {event.preventDefault();});


// запрет просмотра кода (p.s он и так на гитхабе)
document.addEventListener("keydown", function (event) {
    if (event.key === "F12" || 
        (event.ctrlKey && event.shiftKey && event.key === "I") ||
        (event.ctrlKey && event.key === "u")) {
        event.preventDefault();}});

  
        
// функции    
function t() {
            eel.db()(function(response) {
                document.getElementById("gameText").innerText = response;
            });
}

canload = true;

function loadContent(file) {
    fetch('http://localhost:8000/pages/' + file) 
        .then(response => {
            if (!response.ok) {
                throw new Error('Error');
            }
            return response.text();  
        })
        .then(data => {  
            let tempDiv = document.createElement('div');
            tempDiv.innerHTML = data;
            tempDiv.querySelectorAll('script').forEach(script => {
                let newScript = document.createElement('script');
                if (script.src) {
                    newScript.src = script.src;
                } else {
                    newScript.textContent = script.textContent;
                }
                document.body.appendChild(newScript);
            });

            
            document.getElementById('contentDisplay').innerHTML = tempDiv.innerHTML;
            
            
        })
        .catch(error => {console.error('Error: ', error);document.getElementById('contentDisplay').innerHTML = "<h2>Error on try.</h2>";});
    
}


function toggleDropdown() {
    document.getElementById("dropdown").classList.toggle("show");
}


function selectItem(option) {
    alert("Вы выбрали: " + option);
    toggleDropdown(); // Закрыть список после выбора
}


window.onclick = function(event) {
    if (!event.target.matches('.dropdown-btn')) {
        let dropdowns = document.getElementsByClassName("dropdown-content");
        for (let i = 0; i < dropdowns.length; i++) {
            let openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
        }
    }
}


function toggleDropdown() {
    document.getElementById("dropdown").classList.toggle("show");
}


function selectItem(option) {
    alert("Вы выбрали: " + option);
    toggleDropdown();
}


async function updateProfile() {
    let stPath = await eel.get_st_path()(); 
    let correctedPath = stPath.replace(/\\/g, "/"); 
    

    eel.profile(correctedPath, "name")(function(text) {document.getElementById("p1").innerText = text; });
    eel.profile(correctedPath, "avatar")(function(url) {document.getElementById("avatar").src = url;});
}


function rightinfo() {
   

    console.log(document.getElementById("entr").value);
    //console.log(g_name);
    let inputValue = document.getElementById("entr").value;
    eel.search(inputValue)(function(g_name) {

        if (eel.get_name_by_id(g_name) === "none") {
            for (let i = 0; i < 5; i++) {
                if (document.getElementById("pp" + i)) {
                    document.getElementById("pp" + i).innerText = txtnames[i-1] + "not found";
                }
            }  

        }   else {
                eel.get_data_by_id(g_name, 'all')().then((data) => {
                        
                    let txtnames = ['name: ','release date: ','developer: ','publisher: ',];
                    for (let i = 0; i < 5; i++) {
                        if (document.getElementById("pp" + i)) {
                            document.getElementById("pp" + i).innerText = txtnames[i-1] + data[i-1];
                        }
                    }
                });
        }     



        eel.img_data(g_name)(function(response) {
            if (response === "none") {
                document.getElementById("game-icon").src = "icons/non_game.png";
            } else {
                document.getElementById("game-icon").src = response;
            }
        });
    });
}


async function game_add() {


    let inputValue = document.getElementById("entr").value;
    
    //let g_name = 1;
    eel.search(inputValue)(function(g_name) {

        

        console.log(g_name);

        eel.get_name_by_id(g_name)(function(text) {
        
            
            if (text == null) {
                document.getElementById("game_txt").innerText = "Game with ID: <" + g_name + "> not found";
                document.getElementById("game_icon").style.opacity = "0.5";;} 


            else {
                rightinfo()
                eel.add_game(g_name)
                
                ;}    

            tboxer();
            eel.msg("Added");
        });
    });
}


async function game_rem() {
    let inputValue = document.getElementById("entr").value;
    
    eel.search(inputValue)(function(g_name) {
        eel.get_name_by_id(g_name)(function(text) {
            if (text == null) {document.getElementById("game_txt").innerText = "Game with ID: <" + g_name + "> not found";} 

            else {document.getElementById("game_txt").innerText = text;} 
        });

        eel.rem_game(g_name);
        tboxer();
        eel.msg("Removed");
    });
}


function open_profile(callback) {
    let a = "https://steamcommunity.com/profiles/";
    eel.get_st_path()(function(text){  
        eel.profile(text,"id")(function(text){
            console.log(a+text+"/");
            //console.log(g)
            //return a+text+"/";
            let url = a+text+"/";
            callback(url);
        });     
    });  
}


function checkWindowSize() {
    const minWidth = 800;
    const minHeight = 600;
    
    //if (window.innerWidth < minWidth || window.innerHeight < minHeight) {
        //window.resizeTo(minWidth, minHeight);
        //console.log("Loh "+ window.innerWidth + "/" + window.innerHeight);
    //}

    if (window.innerWidth < minWidth) {
        window.resizeTo(minWidth, window.outerHeight);
        
    }
    if (window.innerHeight < minHeight) {
        window.resizeTo(window.outerWidth, minHeight);
        
    }
}

setInterval(checkWindowSize, 500);


let isWriting = false;
let lastIndex = 0; 
function tboxer() {
    if (isWriting) return;
    isWriting = true;

    eel.tbox()(function(response) {
        const textbox = document.getElementById("textbox");

      
        const newLines = response.slice(lastIndex);
        lastIndex = response.length; 

        let i = 0;

        function writeLine() {
            if (i < newLines.length) {
                textbox.value += newLines[i] + "\n";
                textbox.scrollTop = textbox.scrollHeight;
                i++;
                setTimeout(writeLine, 100);
            } else {
                isWriting = false;
            }
        }

        writeLine();
    });
}


function resizewin() {
    if (window.innerWidth < 1000) 
        {
            console.log("");
            window.resizeTo(1000,600);
    };

};

function load(cont) {
    if (canload == true) {
        loadContent(cont); 
    }
   
}


//[SETTINGS]
function s_st_path(id) {
    if (id == "browse") {
        //here some code
    }

    if (id == "input") {
        // here i changing input
        //document.getElementById("st_path_input").value;
        //console.log("ss");
    }
}








//setInterval(s_st_path("input"),1000);








console.log(window.innerWidth);
console.log(window.innerHeight);



//window.onload = checkWindowSize;
//window.onresize = checkWindowSize;

tboxer();
updateProfile();
//loadContent('settings.html'); 


function trr2() {
    console.log(document.getElementById("test142").innerText);
    console.log(document.getElementById("test1488").value);
}








eel.have_db()(function(response) {
    if (response == true) {
        console.log("DB found");
        loadContent('games.html'); 
    }
    else {
        console.log("DB not found");
        loadContent('sry.html');
        canload = false;
    }
});