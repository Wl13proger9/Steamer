
eel.get_version()(function(text) {document.getElementById("p2").innerText = "made by: Wl13Proger9 --- Version: "+text;});


//document.addEventListener("keydown", function (event) {if (event.key === "F5" || (event.ctrlKey && event.key === "r")) {event.preventDefault();}});


//document.addEventListener("contextmenu", function (event) {event.preventDefault();});


// запрет просмотра кода (p.s он и так на гитхабе)
//document.addEventListener("keydown", function (event) {
    //if (event.key === "F12" || 
        //(event.ctrlKey && event.shiftKey && event.key === "I") ||
        //(event.ctrlKey && event.key === "u")) {
        //event.preventDefault();}});

  
        
// функции    
function t() {
            eel.db()(function(response) {
                document.getElementById("gameText").innerText = response;
            });
}


function loadContent(file) {
            fetch('http://localhost:8000/pages/' + file)  // Запрашиваем файл
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Ошибка при загрузке файла');
                    }
                    return response.text();  // Получаем текстовый ответ (HTML)
                })
                .then(data => {
                    // Создаем временный контейнер для парсинга HTML контента
                    let tempDiv = document.createElement('div');
                    tempDiv.innerHTML = data;
        
                    // Извлекаем и выполняем скрипты из загруженного контента
                    tempDiv.querySelectorAll('script').forEach(script => {
                        let newScript = document.createElement('script');
                        if (script.src) {
                            newScript.src = script.src;
                        } else {
                            newScript.textContent = script.textContent;
                        }
                        document.body.appendChild(newScript);
                    });
        
                    // Вставляем HTML в блок
                    document.getElementById('contentDisplay').innerHTML = tempDiv.innerHTML;
                })
                .catch(error => {
                    console.error('Ошибка загрузки файла:', error);
                    document.getElementById('contentDisplay').innerHTML = "<h2>Ошибка при загрузке контента.</h2>";
                });
}


function toggleDropdown() {
    document.getElementById("dropdown").classList.toggle("show");
}


function selectItem(option) {
    alert("Вы выбрали: " + option);
    toggleDropdown(); // Закрыть список после выбора
}


window.onclick = function(event) {
    if (!event.target.matches('.dropdown-btn')) {
        let dropdowns = document.getElementsByClassName("dropdown-content");
        for (let i = 0; i < dropdowns.length; i++) {
            let openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
        }
    }
}


function toggleDropdown() {
    document.getElementById("dropdown").classList.toggle("show");
}


function selectItem(option) {
    alert("Вы выбрали: " + option);
    toggleDropdown();
}


async function updateProfile() {
    let stPath = await eel.get_st_path()(); 
    let correctedPath = stPath.replace(/\\/g, "/"); 
    

    eel.profile(correctedPath, "name")(function(text) {document.getElementById("p1").innerText = text; });
    eel.profile(correctedPath, "avatar")(function(url) {document.getElementById("avatar").src = url;});
}


function rightinfo() {

    //console.log(document.getElementById("entr").value);

    if (eel.get_name_by_id(document.getElementById("entr").value) === "none") {
        for (let i = 0; i < 5; i++) {
            if (document.getElementById("pp" + i)) {
                document.getElementById("pp" + i).innerText = txtnames[i-1] + "not found";
            }
        }  

    }   else {
            eel.get_data_by_id(document.getElementById("entr").value, 'all')().then((data) => {
                    
                let txtnames = ['name: ','release date: ','developer: ','publisher: ',];
                for (let i = 0; i < 5; i++) {
                    if (document.getElementById("pp" + i)) {
                        document.getElementById("pp" + i).innerText = txtnames[i-1] + data[i-1];
                    }
                }
            });
    }     



    eel.img_data(document.getElementById("entr").value)(function(response) {
        if (response === "none") {
            document.getElementById("game-icon").src = "icons/non_game.png";
        } else {
            document.getElementById("game-icon").src = response;
        }
    });
    
}


async function game_add() {
    let inputValue = document.getElementById("entr").value;
    eel.get_name_by_id(inputValue)(function(text) {
        console.log(text);
        if (text == null) {
            document.getElementById("game_txt").innerText = "Game with ID: <" + inputValue + "> not found";
            document.getElementById("game_icon").style.opacity = "0.5";;} 


        else {
            rightinfo()
            eel.add_game(inputValue)
            
            ;}    
            
    });
}


async function game_rem() {
    let inputValue = document.getElementById("entr").value;
    eel.get_name_by_id(inputValue)(function(text) {
        if (text == null) {document.getElementById("game_txt").innerText = "Game with ID: <" + inputValue + "> not found";} 

        else {document.getElementById("game_txt").innerText = text;} 
    });

    eel.rem_game(inputValue);
}


function open_profile(callback) {
    let a = "https://steamcommunity.com/profiles/";
    eel.get_st_path()(function(text){  
        eel.profile(text,"id")(function(text){
            console.log(a+text+"/");
            //console.log(g)
            //return a+text+"/";
            let url = a+text+"/";
            callback(url);
        });     
    });  
}



function checkWindowSize() {
    const minWidth = 1000;
    const minHeight = 600;
    const currentWidth = window.innerWidth;
    const currentHeight = window.innerHeight;
    if (currentWidth < minWidth || currentHeight < minHeight) {window.resizeTo(minWidth, minHeight);}
}




function tboxer() {
    eel.tbox()(function(response) {
        //console.log(response);
        const arrayString = response.join("\n");
        document.getElementById("textbox").value = arrayString;
    });

}

setInterval(tboxer, 500);


//setInterval(checkWindowSize, 1000);



function resizewin() {
    if (window.innerWidth < 1000) 
        {
            console.log("");
            window.resizeTo(1000,600);
    };

};


setInterval(resizewin,1000);


console.log(window.innerWidth);
console.log(window.innerHeight);


//window.onload = checkWindowSize;
//window.onresize = checkWindowSize;


updateProfile();
loadContent('games.html');
